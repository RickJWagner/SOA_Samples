This archive contains the following:

standalone-full.xml, with custom settings for HTTP security.  Remember to start your server with standalone.sh -c standalone-full.xml
properties files, to be placed alongside standalone-full.xml.  These identify the users.
A_JBDS_WS_Sec, is a JBDS project with a simple web service that is secured with basic authentication.  Note the entries in web.xml and jboss-web.xml.
A_SoapCaller, is a SwitchYard project that proxies the web service above.  Note the contents of switchyard.xml

The proxied web service can be accessed via "http://localhost:8080/proxy/HourReporterImplService"

