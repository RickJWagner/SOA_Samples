package com.example;

import javax.jws.WebService;


@WebService
public class HourReporterImpl implements HourReporter {
		
	    
		public String reportOnHour(int hour){
			System.out.println("######Web Service called!#####");
			if (hour < 1 || hour > 24){
				return "Invalid hour:" + hour;
			}
			if (hour < 18){
				return "Day";
			}else{
				return "Night";
			}
		}
	

}
