package com.example;

public interface HourReporter {
	
	public String reportOnHour(int hour);

}
