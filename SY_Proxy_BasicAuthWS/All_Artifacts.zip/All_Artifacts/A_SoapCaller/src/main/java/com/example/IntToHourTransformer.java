package com.example;

import java.io.StringReader;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import org.switchyard.annotations.Transformer;
import org.w3c.dom.Element;

public final class IntToHourTransformer {

	@Transformer(to = "{http://example.com/}reportOnHour")
	public Element transformIntToReportOnHour(int from) {
		String p0 = "<soap:Envelope xmlns:soap=\"";
		String p1 = "http://schemas.xmlsoap.org/soap/envelope/" + "\""; 
		String p2 = "><soap:Body><ns2:reportOnHourResponse xmlns:ns2=\"";
		String p3 = "http://example.com/\"><return>Night</return></ns2:reportOnHourResponse></soap:Body></soap:Envelope>";
		
		String wholeThing = p0 + p1 + p2 + p3;
		
		return toElement(wholeThing);
	}

	@Transformer(from = "{http://example.com/}reportOnHourResponse")
	public String transformReportOnHourResponseToString(Element from) {
		return getElementValue(from, "return");
		
		
	}
	
    private Element toElement(String xml) {
        DOMResult dom = new DOMResult();
        try {
            TransformerFactory.newInstance().newTransformer().transform(new StreamSource(new StringReader(xml)), dom);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ((Document) dom.getNode()).getDocumentElement();
    }	
    
    private String getElementValue(Element parent, String elementName) {
        String value = null;
        NodeList nodes = parent.getElementsByTagName(elementName);
        if (nodes.getLength() > 0) {
            value = nodes.item(0).getChildNodes().item(0).getNodeValue();
        }
        return value;
    }    
    
    public static void main(String [] args){
    	System.out.println(new IntToHourTransformer().transformReportOnHourResponseToString(null));
    }

}
