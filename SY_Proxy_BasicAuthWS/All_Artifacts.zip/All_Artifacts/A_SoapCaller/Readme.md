Introduction
============
This quickstart demonstrates the usage of the Camel Component and it's binding feature, by invoking 
service periodically.

Running the quickstart
======================

JBoss AS 7
----------
1. Build the quickstart:

        mvn clean install

2. Start JBoss AS 7 in standalone-full mode:

        ${AS}/bin/standalone.sh --server-config=standalone-full.xml

3. Deploy the quickstart

        mvn jboss-as:deploy

4. Check the server console for output from the service. By default after every second
   message should be printed

## Further Reading

1. [Quartz Binding Documentation](https://docs.jboss.org/author/display/SWITCHYARD/Quartz)
